#ifndef ESCAPE_H
#define ESCAPE_H

void Esc_findEscape(A_exp exp);

#endif