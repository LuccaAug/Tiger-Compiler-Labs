#ifndef PRINT_TREE_H
#define PRINT_TREE_H

/* function prototype from printtree.c */
void printStmList (FILE *out, T_stmList stmList) ;

#endif

