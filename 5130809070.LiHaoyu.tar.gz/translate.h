#ifndef TRANSLATE_H
#define TRANSLATE_H

#include "temp.h"
#include "frame.h"
#include "absyn.h"

/* Lab5: your code below */

typedef struct patchList_ *patchList;

typedef struct Tr_exp_ *Tr_exp;

typedef struct Tr_access_ *Tr_access;

typedef struct Tr_accessList_ *Tr_accessList;

typedef struct Tr_level_ *Tr_level;

Tr_level Tr_newlevel(Tr_level parent, Temp_label name, U_boolList formals);

Tr_level outermost(void);

Tr_accessList Tr_formals(Tr_level level);

Tr_accessList Tr_AccessList(Tr_access head, Tr_accessList tail);

Tr_access Tr_allocLocal(Tr_level level, bool escape);

void Tr_procEntryExit(Tr_level level, Tr_exp body, Tr_accessList formals);

F_fragList Tr_getResult();

Tr_exp Tr_stringEntryExit(string s);

Tr_exp Tr_simpleVar(Tr_access, Tr_level);

Tr_exp Tr_fieldVar(Tr_exp exp, int offs);

Tr_exp Tr_subscriptVar(Tr_exp exp1, Tr_exp exp2);

Tr_exp Tr_nilExp();

Tr_exp Tr_intExp(int i);

Tr_exp Tr_stringExp(string s);

Tr_exp Tr_opExp(A_oper op, Tr_exp exp1, Tr_exp exp2);

Tr_exp Tr_emptyExp();

#endif
