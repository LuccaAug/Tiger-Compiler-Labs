#include <stdio.h>
#include "util.h"
#include "table.h"
#include "symbol.h"
#include "absyn.h"
#include "temp.h"
#include "tree.h"
#include "printtree.h"
#include "frame.h"
#include "translate.h"

static const int F_WORD_SIZE = 4;

struct Tr_access_ {
	//Lab5: your code here
    Tr_level level;
    F_access access;
};

struct Tr_accessList_ {
    Tr_access head;
    Tr_accessList tail; 
};

struct Tr_level_ {
    //Lab5: your code here
    Tr_level parent;
    F_frame frame;
    Temp_label name;
    Tr_accessList formals;
};

static Tr_access Tr_Access(Tr_level level, F_access access) {
    Tr_access a = checked_malloc(sizeof(*a));
    a->level = level;
    a->access = access;
    return a;
}

Tr_access Tr_allocLocal(Tr_level level, bool escape) {
    Tr_access a = checked_malloc(sizeof(*a));
    a->level = level;
    a->access = F_allocLocal(level->frame, escape);
    return a;
}

Tr_accessList Tr_AccessList(Tr_access head, Tr_accessList tail) {
    Tr_accessList a = checked_malloc(sizeof(*a));
    a->head = head;
    a->tail = tail;
    return a;
}

Tr_accessList Tr_formals(Tr_level level) {
    return level->formals;
}

Tr_level Tr_newlevel(Tr_level parent, Temp_label name, U_boolList formals) {
    Tr_level l = checked_malloc(sizeof(*l));
    l->parent = parent;
    l->name = name;
    l->frame = F_newFrame(name, U_BoolList(TRUE, formals));
    Tr_accessList res = NULL, now;
    F_accessList iter = F_formals(l->frame)->tail;
    for (; iter; iter = iter->tail) {
        Tr_accessList a = checked_malloc(sizeof(*a));
        a->head = Tr_Access(l, iter->head);
        a->tail = NULL;
        if (!res) {
            res = a;
            now = res;
        } else {
            now->tail = a;
            now = a;
        }
    }
    l->formals = res;
    return l;
}

static Tr_level outer = NULL;

Tr_level outermost(void) {
    if (!outer)
        outer = Tr_newlevel(NULL, Temp_newlabel(), NULL);
    return outer;
}

struct patchList_ {
    Temp_label * head;
    patchList tail;
};

struct Cx {
    patchList trues;
    patchList falses;
    T_stm stm;
};

struct Tr_exp_ {
	//Lab5: your code here
    enum {Tr_ex, Tr_nx, Tr_cx} kind;
    union {
        T_exp ex;
        T_stm nx;
        struct Cx cx; 
    } u;
};

static patchList PatchList(Temp_label *head, patchList tail) {
    patchList p = checked_malloc(sizeof(*p));
    p->head = head;
    p->tail = tail;
    return p;
}

static void doPatch(patchList t, Temp_label label) {
    for (; t; t = t->tail) {
        *(t->head) = label;
    }
}

static Tr_exp Tr_Ex(T_exp exp) {
    Tr_exp e = checked_malloc(sizeof(*e));
    e->kind = Tr_ex;
    e->u.ex = exp;
}

static Tr_exp Tr_Nx(T_stm stm) {
    Tr_exp e = checked_malloc(sizeof(*e));
    e->kind = Tr_nx;
    e->u.nx = stm;
}

static Tr_exp Tr_Cx(patchList t, patchList f, T_stm stm) {
    Tr_exp e = checked_malloc(sizeof(*e));
    e->kind = Tr_cx;
    e->u.cx.trues = t;
    e->u.cx.falses = f;
    e->u.cx.stm = stm;
}

static T_exp unEx(Tr_exp e) {
    switch (e->kind) {
        case Tr_ex:
            return e->u.ex;
        case Tr_nx:
            return T_Eseq(e->u.nx, T_Const(0));
        case Tr_cx: {
            Temp_temp r = Temp_newtemp();
            Temp_label t = Temp_newlabel(), f = Temp_newlabel();
            doPatch(e->u.cx.trues, t);
            doPatch(e->u.cx.falses, f);
            return T_Eseq(T_Move(T_Temp(r), T_Const(1)),
                          T_Eseq(e->u.cx.stm,
                                 T_Eseq(T_Label(f),
                                        T_Eseq(T_Move(T_Temp(r), T_Const(0)),
                                               T_Eseq(T_Label(t), T_Temp(r))))));
        }
    }
}

static T_stm unNx(Tr_exp e) {
    if (!e) return NULL;
    switch (e->kind) {
        case Tr_ex:
            return T_Exp(e->u.ex);
        case Tr_nx:
            return e->u.nx;
        case Tr_cx: {
            Temp_temp r = Temp_newtemp();
            Temp_label t = Temp_newlabel(), f = Temp_newlabel();
            doPatch(e->u.cx.trues, t);
            doPatch(e->u.cx.falses, f);
            return T_Exp(T_Eseq(T_Move(T_Temp(r), T_Const(1)),
                                T_Eseq(e->u.cx.stm,
                                       T_Eseq(T_Label(f),
                                              T_Eseq(T_Move(T_Temp(r), T_Const(0)),
                                                     T_Eseq(T_Label(t), T_Temp(r)))))));
    
        }
    }
}

static struct Cx unCx(Tr_exp e) {
    switch (e->kind) {
        case Tr_ex: {
            struct Cx cx;
            cx.stm = T_Cjump(T_eq, e->u.ex, T_Const(1), NULL, NULL);
            cx.trues = PatchList(&(cx.stm->u.CJUMP.true), NULL);
            cx.falses = PatchList(&(cx.stm->u.CJUMP.false), NULL);
            return cx;
        }
        case Tr_nx:
            assert(0);
        case Tr_cx:
            return e->u.cx;
    }
}

static F_fragList procFragList = NULL;
void Tr_procEntryExit(Tr_level level, Tr_exp body, Tr_accessList formals) {
    F_frag frag = F_newProcFrag(unNx(body), level->frame);
    procFragList = F_FragList(frag, procFragList);
}

static F_fragList stringFragList = NULL;
Tr_exp Tr_stringExp(string s) {
    Temp_label label = Temp_newlabel();
    F_frag frag = F_StringFrag(label, s);
    stringFragList = F_FragList(frag, stringFragList);
    return Tr_Ex(T_Name(label));
}

F_fragList Tr_getResult() {
    F_fragList pre = NULL, now;
    for (now = stringFragList; now; now = now->tail)
        pre = now;
    if (pre) {
        pre->tail = procFragList;
        return stringFragList;
    }
    return procFragList;
}

Tr_exp Tr_simpleVar(Tr_access var, Tr_level level) {
    T_exp offset = T_Temp(F_FP());
    while (level != var->level->parent) {
        F_access a = F_formals(level->frame)->head;
        offset = F_Exp(a, offset);
        level = level->parent;
    }
    return Tr_Ex(F_Exp(var->access, offset));
}

Tr_exp Tr_fieldVar(Tr_exp exp, int offs) {
    return Tr_Ex(T_Mem(T_Binop(T_plus, unEx(exp), T_Const(offs * F_WORD_SIZE))));
}

Tr_exp Tr_subscriptVar(Tr_exp exp1, Tr_exp exp2) {
    return Tr_Ex(T_Mem(T_Binop(T_plus, unEx(exp1),
                               T_Binop(T_mul, unEx(exp2), T_Const(F_WORD_SIZE)))));
}

static Temp_temp nilTemp = NULL;
Tr_exp Tr_nilExp() {
    if (!nilTemp) {
        nilTemp = Temp_newtemp();
        T_stm alloc = T_Move(T_Temp(nilTemp),
                             F_externalCall(String("initRecord"), T_ExpList(T_Const(0), NULL)));
        return Tr_Ex(T_Eseq(alloc, T_Temp(nilTemp)));
    }
    return Tr_Ex(T_Temp(nilTemp));
}

Tr_exp Tr_intExp(int i) {
    return Tr_Ex(T_Const(i));
}

Tr_exp Tr_opExp(A_oper op, Tr_exp exp1, Tr_exp exp2) {
    T_binOp oper;
    if (op == A_plusOp)   oper = T_plus;
    if (op == A_minusOp)  oper = T_minus;
    if (op == A_timesOp)  oper = T_mul;
    if (op == A_divideOp) oper = T_div;
    return Tr_Ex(T_Binop(oper, unEx(exp1), unEx(exp2)));
}

Tr_exp Tr_emptyExp() {
    return Tr_Ex(T_Const(0));
}